#pragma once
#include "cocos2d.h"

class MainMenu :public cocos2d::Layer
{
public:
	//Functions
	static cocos2d::Scene* createScene(); //Function to create the scene for the main menu
	virtual bool init(); //Function to initialise the main menu
	void initMainMenu(); //Function to create menu buttons
	void mainMenuPlay(cocos2d::Ref* sender);
	void menuCloseCallBack(cocos2d::Ref*pSender); //A selector callback

	//Implementing 
	CREATE_FUNC(MainMenu);
};
