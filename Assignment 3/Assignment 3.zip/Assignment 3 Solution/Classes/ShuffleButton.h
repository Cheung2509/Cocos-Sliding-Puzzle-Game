#pragma once
#include "cocos2d.h"

class ShuffleButton : public cocos2d::Sprite
{
public:
	ShuffleButton() = default;
	~ShuffleButton() = default;
	static ShuffleButton* create();

};
