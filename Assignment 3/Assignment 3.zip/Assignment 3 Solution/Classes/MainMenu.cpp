#include "MainMenu.h"
#include "GameScene.h"
USING_NS_CC;

//Function to create a scene for the main menu
cocos2d::Scene*MainMenu::createScene()
{
	cocos2d::Scene*scene = Scene::create();
	auto layer = MainMenu::create();
	
	scene->addChild(layer); //add layer as a child to scene

	return scene;	//Return Scene
}

bool MainMenu::init()
{
	if (!Layer::init())
	{
		return false;
	}
	cocos2d::Label* label = Label::createWithTTF("Sliding Puzzle", "fonts/Marker Felt.ttf", 24);
	label->setPosition(Vec2(512, 500));
	this->addChild(label, 1);
	initMainMenu();

	return true;
}
//Function to initialise Main Menu
void MainMenu::initMainMenu()
{
	//Creating menu itemm to play the game
	MenuItemFont* mainMenuPlay = MenuItemFont::create(
		"Play",
		CC_CALLBACK_1(MainMenu::mainMenuPlay, this));
	//Creating menu item to exit the application
	MenuItemFont* mainMenuExit = MenuItemFont::create(
		"Exit Game",
		CC_CALLBACK_1(MainMenu::menuCloseCallBack, this));

	cocos2d::Menu* menu = Menu::create(mainMenuPlay, mainMenuExit, nullptr);
	menu->alignItemsVertically();
	this->addChild(menu, 1);

}
//Finction to transition to play the game
void MainMenu::mainMenuPlay(cocos2d::Ref* sender)
{
	Director::getInstance()->replaceScene(
		TransitionFlipY::create(2, GameScene::createScene()));
}

//A selector callback
void MainMenu::menuCloseCallBack(cocos2d::Ref*pSender)
{
	Director::getInstance()->end();
}